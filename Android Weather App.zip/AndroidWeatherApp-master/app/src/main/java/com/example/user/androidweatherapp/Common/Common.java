package com.example.user.androidweatherapp.Common;

import android.location.Location;

/**
 * Created by User on 7/28/2018.
 */

public class Common {
    public static final String APP_ID = "6786f8907c7acda3082854353f3591dc";
    public static Location current_location=null;
}
