package com.example.user.androidweatherapp.Model;

/**
 * Created by User on 7/28/2018.
 */

public class Clouds {
    private int all ;

    public Clouds() {
    }

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }
}
